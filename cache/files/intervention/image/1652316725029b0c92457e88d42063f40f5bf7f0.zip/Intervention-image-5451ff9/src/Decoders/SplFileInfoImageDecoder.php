<?php

declare(strict_types=1);

namespace Intervention\Image\Decoders;

use Intervention\Image\Drivers\SpecializableDecoder;

class SplFileInfoImageDecoder extends SpecializableDecoder
{
}
