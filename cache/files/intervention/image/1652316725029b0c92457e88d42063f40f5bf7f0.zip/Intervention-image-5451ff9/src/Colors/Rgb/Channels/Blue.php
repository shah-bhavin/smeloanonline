<?php

declare(strict_types=1);

namespace Intervention\Image\Colors\Rgb\Channels;

class Blue extends Red
{
}
